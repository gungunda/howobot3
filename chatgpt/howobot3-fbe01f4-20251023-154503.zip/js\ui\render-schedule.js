"use strict";

/** Заглушка рендера расписания. */
export function renderSchedule(root) {
  const el = document.createElement("div");
  el.textContent = "Редактор расписания появится здесь.";
  root.appendChild(el);
}
