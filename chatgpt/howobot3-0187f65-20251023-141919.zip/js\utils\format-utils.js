"use strict";

/** Общие функции форматирования (заглушка). */
export function pad2(n) { return String(n).padStart(2, "0"); }
