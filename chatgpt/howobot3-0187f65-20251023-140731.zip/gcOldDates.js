"use strict";

/** Заглушка: удаление устаревших override-дней по правилу. */
export function gcOldDates(_todayKey) { /* TODO */ }
