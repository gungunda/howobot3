"use strict";

/** Заглушка: в будущем здесь будет синхронизация Local ↔ Cloud по LWW. */
export async function syncNow() { /* TODO */ }
